<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="assets/css/bootstrap.css">
</head>

<body>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-6 m-auto justify-items-center">
                <form action="index.php?a=processLogin&c=login" method="POST" onsubmit="return checkForm()">
                    <div class="form-floating mb-3">
                        <h3 class="text-center">ADMIN MANAGEMENT DASHBOARD</h3>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="username" id="floatingInput" placeholder="name@example.com">
                        <label for="floatingInput">Email address</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="password" class="form-control" name="password" id="floatingPassword" placeholder="Password">
                        <label for="floatingPassword">Password</label>
                    </div>
                    <?php if (isset($_COOKIE['error_login'])) { ?>

                        <div class="alert alert-danger" role="alert"><?= $_COOKIE['error_login'] ?></div>

                    <?php } ?>
                    <div class="col-sm-12 mt-3 text-center">
                        <button class="btn btn-primary" type="submit" name="login">Đăng nhập</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="assets/js/bootstrap.js"></script>
    <script>
        function checkForm() {
            return true;
        }
    </script>
</body>

</html>