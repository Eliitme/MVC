<?php
  echo "Tên tôi là: $name, năm nay tôi $age tuổi";
?>